package th.co.ais.ipfm.poi.util

class GXLSColumn {

	String entity
	String label
	Short position
	
	public GXLSColumn(String entity, String label) {
		this.entity = entity;
		this.label = label;
	}
	
	public GXLSColumn(String entity, Short position) {
		this.entity = entity;
		this.position = position;
	}
	
	public GXLSColumn(String entity, String label, int position) {
		this.entity = entity;
		this.label = label;
		this.position = position;
	}

}
