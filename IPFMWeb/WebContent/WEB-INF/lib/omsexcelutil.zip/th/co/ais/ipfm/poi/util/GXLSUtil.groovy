/**
 *
 */
package th.co.ais.ipfm.poi.util

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.codehaus.groovy.tools.shell.util.ClassNameCompletor;

/**
 * @author Jaturawit Duangmanee
 * GXLSUtil = Groovy Excel Utilities
 */
class GXLSUtil {
	
	private static def getCellValue(HSSFCell cell) {
		def value = null;;
		switch (cell?.getCellType()) {
			case HSSFCell.CELL_TYPE_BOOLEAN:
				value = cell.getBooleanCellValue();
				break;
			case HSSFCell.CELL_TYPE_NUMERIC:
				value = cell.getNumericCellValue();
				break;
			case HSSFCell.CELL_TYPE_STRING:
				value = cell.getStringCellValue();
				break;
		}
		return value
	}

	/**
	 * @param from From cell
	 * @param to To cell
	 * @param style clone style or not?
	 * @param style clone value or not?
	 */
	public final static void cloneCell(HSSFCell from, HSSFCell to, boolean style, boolean value) {
		if(style==true)
			to.setCellStyle(from.getCellStyle());
		if(value==true)
			if(from.getCellType()==HSSFCell.CELL_TYPE_FORMULA) 
				to.setCellFormula(from.getCellFormula());
			else {
				def v = getCellValue(from);
				if(v)
					to.setCellValue(v);
			}
	}
	
	/**
	 * @param from From row
	 * @param to To row
	 * @param style clone style or not?
	 * @param style clone value or not?
	 *
	 * @return to row
	 */
	public final static HSSFRow cloneRow(HSSFRow from, HSSFRow to, boolean style, boolean value) {
		for (int i = 0; i < from.getLastCellNum(); i++)
			cloneCell(from.getCell(i), to.createCell(i), style, value);
		return to;
	}
	
	public final static HSSFRow insetRowAfter(HSSFSheet sheet, int position, boolean style, boolean value) {
		sheet.shiftRows(position+1, sheet.getLastRowNum(), 1);
		return cloneRow(sheet.getRow(position), sheet.createRow(position+1), style, value);
	}
	
	public final static HSSFRow insetRowBefore(HSSFSheet sheet, int position, boolean style, boolean value) {
		sheet.shiftRows(position, sheet.getLastRowNum(), 1);
		return cloneRow(sheet.getRow(position+1), sheet.createRow(position), style, value);
	}
	
	public final static HSSFWorkbook toWorkbook(String template, List<GXLSColumn> columns, List dataList) {
		def iR = 0;	// row index
		HSSFWorkbook wb
		HSSFSheet sheet
		if(!template) {
			wb = new HSSFWorkbook();
			sheet = wb.createSheet("Sheet");
			columns.eachWithIndex { column, position ->
				column.position = position
			}
			
			// header		
			HSSFRow row = sheet.createRow(iR);
			columns.each { column ->
				HSSFCell cell = row.createCell(column.position);
				cell.setCellValue(column.label?:column.entity);
			}
		}
		else {
			wb = new HSSFWorkbook(new FileInputStream(template));
			sheet = wb.getSheetAt(0);
		}
		
		// date
		iR = 1;
		dataList.each { data ->
			HSSFRow row
			if(!template)
				row = sheet.createRow(iR);
			else
				row = insetRowAfter(sheet, iR, true, false);
			columns.each { column ->
				HSSFCell cell = row.createCell(column.position);
				cell.setCellValue(data[column.entity]);
			}
			iR++;
		}
		
		if(template) {
			sheet.shiftRows(2, iR, 1)
			sheet.shiftRows(3, sheet.lastRowNum, -2)
		}

		return wb;
	}
	
	public final static void toFile(String template, List<GXLSColumn> columns, List dataList, String outFile) {
		HSSFWorkbook wb = toWorkbook(template, columns, dataList)
		FileOutputStream fileOut = new FileOutputStream(outFile);
		wb.write(fileOut);
		fileOut.close();
	}
	
	public final static List fromWorkbook(HSSFWorkbook wb, List<GXLSColumn> columns, Class className) {
		def dataList = [];
		HSSFSheet sheet = wb.getSheetAt(0);
		for(int i=1; i<=sheet.lastRowNum; i++) {
			HSSFRow row = sheet.getRow(i)
			def data = Class.forName(className.getName()).newInstance();
			columns.each { column ->
				HSSFCell cell = row.getCell(column.position);
				if(cell)
					data[column.entity] = getCellValue(cell);
			}
			dataList << data
		}

		return dataList;
	}

	public final static List fromFile(String inFile, List<GXLSColumn> columns, Class className) {
		HSSFWorkbook wb = new HSSFWorkbook(new FileInputStream(inFile));
		return fromWorkbook(wb, columns, className);
	}

	public final static List fromFile(InputStream inputStream, List<GXLSColumn> columns, Class className) {
		HSSFWorkbook wb = new HSSFWorkbook(inputStream);
		return fromWorkbook(wb, columns, className);
	}
	
}

